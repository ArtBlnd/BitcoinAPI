package Base;

public class CoinInfo
{
    public int MaxPrice;
    public int MinPrice;
    public int AvgPrice;
}
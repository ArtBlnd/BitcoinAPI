package Base;

public enum EnumCoinTypes
{
    Etherium,
    EtheriumClassic,
    Bitcoin,
    Dash,
    LightCoin,
    Ripple
}
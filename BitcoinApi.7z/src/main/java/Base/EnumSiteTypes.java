package Base;

public enum EnumSiteTypes 
{
    Poloniex,
    Bithumb,
    CoinOne,
    Yunbi,
    Bittrex,
    BitfineEx,
    BitStamp,
    OkCoin
}